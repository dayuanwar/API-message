INSERT INTO rakamin.message_detail (code_header,message,placement,created_at,updated_at) VALUES
	 ('M00001','pagi bro gimana kabarnya','left','2021-12-06 09:27:51.0',NULL),
	 ('M00001','alhamdulillah bro baik baik aja nih','right','2021-12-06 09:28:10.0',NULL);