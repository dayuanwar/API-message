INSERT INTO rakamin.users (name,email,password,created_at,updated_at) VALUES
	 ('dayu','dayuanwar@gmail.com','$2y$10$Z.XOw3PFE7tgfFqcYYP.Ju9t44CWSHSwH85DIcBDdAoZojYRUyRie','2021-06-12 00:00:00.0',NULL),
	 ('imam','imam@gmail.com','$2y$10$Z.XOw3PFE7tgfFqcYYP.Ju9t44CWSHSwH85DIcBDdAoZojYRUyRie','2021-06-12 00:00:00.0',NULL),
	 ('fudin','fudin@gmail.com','$2y$10$Z.XOw3PFE7tgfFqcYYP.Ju9t44CWSHSwH85DIcBDdAoZojYRUyRie','2021-06-12 00:00:00.0',NULL);