INSERT INTO rakamin.message_header (code,`from`,`to`,last_message,created_at,updated_at) VALUES
	 ('M00001',1,2,'alhamdulillah bro baik baik aja nih','2021-12-06 09:01:02.0','2021-12-06 09:28:10.0');