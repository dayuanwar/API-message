INSERT INTO rakamin.migrations (migration,batch) VALUES
	 ('2014_10_12_000000_create_users_table',1),
	 ('2014_10_12_100000_create_password_resets_table',1),
	 ('2019_08_19_000000_create_failed_jobs_table',1),
	 ('2019_12_14_000001_create_personal_access_tokens_table',1),
	 ('2021_12_06_082452_create_message_header',2),
	 ('2021_12_06_082502_create_message_detail',3);